<!-- footer.php -->
<!-- Bootstrap 5 JS -->

<!-- Bootstrap 5.3 JavaScript + Popper.js (CDN) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"

        crossorigin="anonymous"></script>
</body>
</html>